<?php

define('BANKNAME', 'Bank Of Canada');
define('AUTHOR', 'Harpreet kaur');
define('BANKLOGO', 'images/logo.png');
define('COPYRIGHT', 'Copyright Bank Of Canada
© 2020');
