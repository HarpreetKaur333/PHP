    <footer>
        <div class="isi-footer-top-holder">
            <div class="isi-footer-top-inner ">
                <div class="isi-footer-row">

                    <div class="isi-footer-md-col-4 footergrid">
                        <div class="footer-title-holder">
                            <h4 class="footertitle">About</h4>
                            <p class="footerp intro">
                            </p>
                            <p class="footerp intro"><i style="margin-right: 10px;"><img src="images/locationicon.jpg"
                                        alt="location" class="infoaboutclg"
                                        style="width: 14px;"></i><?php// echo HEADOFFICE; ?>
                            </p>
                            <p class="footerp intro"><i style="margin-right: 10px;"><img src="images/phoneicon.png"
                                        alt="location" class="infoaboutclg" style="width: 14px;"></i>+1 514 842 2426</p>
                            <p class="footerp intro"><i style="margin-right: 10px;"><img src="images/timeicon.png"
                                        alt="location" class="infoaboutclg"
                                        style="width: 14px;"></i><?php// echo TIME; ?>
                            </p>
                        </div>
                    </div>

                    <div class="isi-footer-md-col-4 footergrid">
                        <div class="footer-title-holder">
                            <h4 class="footertitle">Affiliate Sites</h4>
                            <p class="footerp intro">Bank of Canada Museum</p>
                            <p class="footerp intro">Canada Savings Bonds</p>
                            <p class="footerp intro">Unclaimed Balances </p>
                        </div>
                    </div>
                    <div class="isi-footer-md-col-4 footergrid">
                        <div class="footer-title-holder">
                            <h4 class="footertitle">Instagram</h4>
                            <img src="images/instpic.png" alt="Instagram" style="width: 100%;">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    </body>

    </html>