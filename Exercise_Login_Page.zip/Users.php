<?php

class Users
{
    public function __construct()
    {
    }

    public function __destruct()
    {
    }

    public function Login($msg = '')
    {
        if (isset($_SESSION['login_count']) and $_SESSION['login_count'] > 3) {
            Crash('403', 'You are Blocked, try again..!!');
        }
        $pageData['title'] = 'Login Users';
        $pageData['description'] = 'Login Users details';
        $pageData['content'] = <<<HTML
            <h3>Login Page Of Users</h3>
            <h5 style="color:red">$msg</h5>
            <!-- <form action="index.php" method="GET"> -->
            <form action="index.php?op=2" method="POST">
            <input type="hidden" name="op" value="2">
            Email  <input type="text" name="email" placeholder="Email" maxlength="255" required><br> <br>
            Password  <input type="password" name="pw" placeholder="Password" maxlength="10" required><br>
            <input type="submit" value="Continue">
            <br>
            </form>
            <br>
HTML;

        $webPage = new WebPage();
        $webPage->render($pageData);
    }

    public function Login_Verify()
    {
        //use hard code for users
        $Users = [
            ['id' => 0, 'email' => 'Yannick@gmail.com', 'pw' => '12345678'],
            ['id' => 1, 'email' => 'Victor@test.com', 'pw' => '11111111'],
            ['id' => 2, 'email' => 'Christian@victoire.ca', 'pw' => '22222222'],
           ['id' => 3, 'email' => 'hk@gmail.com', 'pw' => '123'],
        ];

        // var_dump($_POST);

        if (isset($_POST['email'])) {
            $email = $_POST['email'];
            if (strlen($email) > 255) {
                Crash(500, 'Email length is too long..!!');
            }
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errormsg = 'invalid email format..!!';
            }
        } else {
            Crash(500, 'field name email is not found..!!');
        }

        if (isset($_POST['pw'])) {
            $pw = $_POST['pw'];
            if (strlen($pw) > 8) {
                Crash(500, 'field length is too long..!!');
            }
        } else {
            Crash(500, 'field Password is not set by user..!!');
        }
        if (isset($errormsg)) {
            self::Login($errormsg);
        }
        foreach ($Users as $one_users) {
            if ($one_users['email'] === $email and $one_users['pw'] === $pw) {
                $_SESSION['email'] = $email;

                $pageData['title'] = 'connected';
                $pageData['content'] = '<h3>You are connected</h3> Welcome back '.$email.'.!!';

                $webPage = new WebPage();
                $webPage->render($pageData);
                exit();
            }
        }
        if (isset($_SESSION['login_count'])) {
            $_SESSION['login_count'] = 1;
        } else {
            ++$_SESSION['login_count'];
            if ($_SESSION['login_count'] > 3) {
                Crash('403', 'You are blocked, try again after some time..!!');
            }
        }
        self::Login('email and password is not found.please try again');
    }

    public function Logout()
    {
        $_SESSION['email'] = null;
        $pageData['title'] = 'Logged Out';
        $pageData['content'] = '<h3>You are Logged out..!!!<h3>';

        $webPage = new WebPage();
        $webPage->render($pageData);
    }
}
