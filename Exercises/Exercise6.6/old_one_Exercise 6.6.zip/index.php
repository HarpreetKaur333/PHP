<!DOCTYPE html>
<html>
<?php
$title = 'Exercise 6.6';
$description = 'Exercise 6.6 using two files and switch case.';
$content = 'Exercise 6.6';
?>

<body>

    <head>
        <?php
        // if (!isset($content)) {
        //     Crash(500, 'web page content is not set in web page');
        // }
        ?>
        <title><?php echo $title; ?>
        </title>
        <meta name="description" value="<?php echo $description; ?>">
        </meta>
        <meta name="viewport" content="width=device-width,initial-scale=1">
        </meta>
    </head>
    <?php
    require_once 'header.php';

     require_once 'product_table.php';
     require_once 'Products_Catalogue_table.php';

 if (isset($_GET['op'])) {
     $op = $_GET['op'];
     switch ($op) {
        case 110:
             Products_List();
            break;
        case 111:
            Products_Catalogue();
            break;
        case 99:
            header('Content-type: application/pdf');
            header('Content-Dispostion:attachment;filename=some_file.pdf');
            readfile('HarpreetKaur_CV.pdf');
            exit();
            break;
        default:
            header('HTTP/1.0  400 Operation not supported- bad Op code-file index not found..!!');
            exit();
    }
 }

require_once 'footer.php';

?>
</body>

</html>