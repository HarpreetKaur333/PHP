<header>
    <title>ElectricScooter.com</title>
    <link rel="stylesheet" href="CSS_of_ex6-6.css" />
</header>
<div class="navbar">
    <a href="#">
        <img src="products_images/elctric_scooter_logo.png" alt="logoImage" class="logo_pic">
    </a>
    <h1 class="company_name">ElectricScooter.com</h1>
</div>
<h3>Product List-Electric Scooter Inc.</h3>