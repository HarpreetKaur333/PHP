<div class="footer">
    <h2>This is the footer</h2>
</div>