<?php
    // if (!isset($index_loaded)) {
    //     header('HTTP / 01 400 this page can not be accessed directly');
    //     exit('this page cannot accessed directly');
    // }
    ?>

     <footer class="page-footer font-small top-bar-wrap">
        <div class="container">

             <!-- Grid row-->
             <div class="row">
             </div>

             <div class="footer-copyright text-center py-3">© 2020 Copyright:
                 <a href="#">Canada Bank</a>
            </div>
        </div>

     </footer>
     </body>

     </html>