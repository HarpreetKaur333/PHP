<?php

 function Display_Msg($msg)
 {
     echo $msg;
 }
